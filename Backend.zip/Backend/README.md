# Hack2Ledger APIs

## Signup

10.0.0.0.1:8000/auth/signup

REQUEST METHOD : POST

data_format : 

{
    "user_id":,
    "wallet+address":,
    "name":,
    "email":,
    "role:",
    "password":,

}

return output:

{
    "message":true
}